﻿Public Class Form1

    Private Sub StudentBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles StudentBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.StudentBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.StudentDataSet)
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'StudentDataSet.student' table. You can move, or remove it, as needed.
        Me.StudentTableAdapter.Fill(Me.StudentDataSet.Student)

    End Sub

    Private Sub btnPrev_Click(sender As Object, e As EventArgs) Handles btnPrev.Click
        StudentBindingSource.MovePrevious()
    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        StudentBindingSource.MoveNext()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        StudentBindingSource.AddNew()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim msgResult As MsgBoxResult
        msgResult = MsgBox("Are you sure want to DELETE this record?", vbYesNo, "Student Details")

        If msgResult = vbYes Then
            StudentBindingSource.RemoveCurrent()
            TableAdapterManager.UpdateAll(StudentDataSet)
            MsgBox("Record has been DELETED", MsgBoxStyle.Exclamation)
        End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            Me.Validate()
            StudentBindingSource.EndEdit()
            StudentTableAdapter.Update(StudentDataSet.Student)
            MessageBox.Show("Record has been SAVED successfully!", "Student Details")

        Catch ex As Exception
            MsgBox("Error occurred. Please check all the fields", MsgBoxStyle.Exclamation, "Student Details")
        End Try
    End Sub


    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Dim msgResult As MsgBoxResult
        msgResult = MsgBox("Are you sure want to EXIT this program", vbYesNo)

        If msgResult = vbYes Then
            Me.Close()
        End If
    End Sub
End Class
